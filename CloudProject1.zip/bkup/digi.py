# Lavanya Somashekar
# CSE 6331

import os
import gnupg
def digital_sign_check(f_name, sign_file):
	gpg = gnupg.GPG()

	#digital signature

	with open(f_name, 'rb') as f:
   		signed_data = gpg.sign_file(f,passphrase='lav123',detach=True)
   		f.close()
	with open(sign_file, 'wb') as f:
   		f.write(str(signed_data))    
   		f.close() 
	with open(sign_file, 'rb') as f:
   		verified=gpg.verify_file(f,f_name)
   		f.close()
	print "Verified" if verified else "Unverified"

'''
References
1. https://pythonhosted.org/python-gnupg/
2. https://docs.python.org/2/library/tkinter.html
3. https://www.dropbox.com/developers/core/sdks/python
4. https://developers.google.com/drive/web/quickstart/quickstart-python
5. https://pythonhosted.org/python-gnupg/
'''
