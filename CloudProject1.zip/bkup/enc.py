# Lavanya Somashekar
# CSE 6331

import os
import dropbox
import hashlib
import mimeparse
import mimetypes
import httplib2
import pprint
import os, random, struct
import gnupg
from Crypto.Cipher import AES
from Crypto.Cipher import AES
from apiclient.discovery import build
from apiclient.http import MediaFileUpload
from oauth2client.client import OAuth2WebServerFlow

# Check https://developers.google.com/drive/scopes for all available scopes
OAUTH_SCOPE = 'https://www.googleapis.com/auth/drive'

# Get your app key and secret from the Dropbox developer website
app_key = '1bb1g8k8r63sext'
app_secret = '76ohlmjf7pi1mn2'

# Copy your credentials from the google console
CLIENT_ID = '671323044118-1fp7ug97i0uf0nogjkmodv88bs0oep65.apps.googleusercontent.com'
CLIENT_SECRET = 'U5gEiN9jCL5kWNjJpL7h8lUl'

flow = dropbox.client.DropboxOAuth2FlowNoRedirect(app_key, app_secret)

# Authorize the token internally
code = 'QZIyCOuenusAAAAAAAAAgWHiAZp1rqVYF1uw_iOtijAFmzggoLG87VDSCf7d8COC'
client = dropbox.client.DropboxClient(code)
print 'linked account: ', client.account_info()

# Redirect URI for installed apps
REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'

key = '0123456789abcdef'
IV = 16 * '\x00'           # Initialization vector: discussed later
mode = AES.MODE_CBC
encryptor = AES.new(key, mode, IV=IV)

gpg = gnupg.GPG()
gpg.encoding = 'utf-8'

# Run through the OAuth flow and retrieve credentials
flow = OAuth2WebServerFlow(CLIENT_ID, CLIENT_SECRET, OAUTH_SCOPE,
                           redirect_uri=REDIRECT_URI)
authorize_url = flow.step1_get_authorize_url()
print 'Go to the following link in your browser: ' + authorize_url
code = raw_input('Enter verification code: ').strip()
#code=AIzaSyCkuZ4FVKiHcGmd17VRHqQHNJFaSlm_D8w
credentials = flow.step2_exchange(code)

# Create a httplib2.Http object and authorize it with our credentials
http = httplib2.Http()
http = credentials.authorize(http)
drive_service = build('drive', 'v2', http=http)

#Encrypt File
from digi import digital_sign_check as dsc
def encrypt(fpath): 
	
	print 'Encrypting file...........', fpath
	f = open(fpath, 'rb')
	fname = fpath.split('/')[-1]
	dsc(fname, 'test_sign')
	out_filename = fpath + '.des'
	
	status = gpg.encrypt_file(f, recipients=['slavanya145@gmail.com'], output=out_filename)

	print 'ok: ', status.ok
	print 'status: ', status.status
	print 'stderr: ', status.stderr

	#Upload the digitally signed and encrypted file to dropbox
	print 'Uploading file..........'
	f = open(out_filename, 'rb')
	f1 = open('test_sign', 'rb')
	response = client.put_file('/' + fname, f, overwrite=False)
        response1 = client.put_file('/' + 'test_sign', f1, overwrite=False)
	print 'UPLOADED Complete \n', response
        print 'UPLOADED Complete \n', response1


	#Upload file to google
	(mime_type, encoding) = mimetypes.guess_type(fname+'.des')
	media_body = MediaFileUpload(out_filename, mimetype='text/plain', resumable=False)
	body = {
	'title': fname,
	'description': 'A Filerazor encrypted file',
	'mimeType': mime_type
	}
	file = drive_service.files().insert(body=body, media_body=media_body).execute()
	pprint.pprint(file)
	print out_filename + ' Encrypted and uploaded succesfully!' 

#Decrypt File

def decrypt_file(fpath):
	print fpath
	f = open(fpath, 'rb')
	if fpath.endswith(".des"):
       	    out_filename = fpath[:-4]
   	if not fpath:
	    out_filename = os.path.splitext(fpath)[0]

	status = gpg.decrypt_file(f, passphrase='lav123', output=out_filename)
	print "ok ? ", status.ok
	print "errors :" 
	print status.stderr
	print "Status "
	print status.status

	#verify the signed file
	dsc(out_filename, 'test_sign')

'''
References
1. https://pythonhosted.org/python-gnupg/
2. https://docs.python.org/2/library/tkinter.html
3. https://www.dropbox.com/developers/core/sdks/python
4. https://developers.google.com/drive/web/quickstart/quickstart-python
5. https://pythonhosted.org/python-gnupg/
'''
