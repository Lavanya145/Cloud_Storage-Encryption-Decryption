# Lavanya Somashekar
# CSE 6331

import Tkinter,tkFileDialog
from enc import *
from enc import encrypt as ef1
from enc import decrypt_file as df1
from Tkinter import *
from tkFileDialog import askopenfilename      

def encrypt():
    name = askopenfilename()
    ef1(name)

def decrypt_file():
    name = askopenfilename()
    df1(name)

#GUI code
root = Tk()
frame = Frame(root)
frame.pack()

bottomframe = Frame(root)
bottomframe.pack( side = BOTTOM )

redbutton = Button(frame, text="Close", command=frame.quit, fg="red")
redbutton.pack( side = LEFT)

greenbutton = Button(frame, text="Encrypt file", command=encrypt, fg="brown")
greenbutton.pack( side = LEFT )

bluebutton = Button(frame, text="Decrypt file", command=decrypt_file, fg="blue")
bluebutton.pack( side = LEFT )

root.mainloop()

'''
References
1. https://pythonhosted.org/python-gnupg/
2. https://docs.python.org/2/library/tkinter.html
3. https://www.dropbox.com/developers/core/sdks/python
4. https://developers.google.com/drive/web/quickstart/quickstart-python
5. https://pythonhosted.org/python-gnupg/
'''
